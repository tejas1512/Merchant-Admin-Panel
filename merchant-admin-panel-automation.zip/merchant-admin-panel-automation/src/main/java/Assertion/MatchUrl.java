package Assertion;

public class MatchUrl {


	public void verifyTitle(String expVal, String ActVal)
	{
		if(expVal.equals(ActVal))
		{
			System.out.println(ActVal + " page title Matched");
		}
		else
		{
			System.out.println(ActVal + " page title not Matched");
		}
	}

	public void verifyPageURL(String expVal, String ActVal)
	{
		expVal.equals(ActVal);
	}

	public void verifyText(String expVal, String ActVal)
	{
		expVal.equals(ActVal);
	}

}



