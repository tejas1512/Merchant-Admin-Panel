package CommonMethod;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

public class FirefoxBrowser {

	WebDriver driver;


//	public WebDriver launchFirefox()
//	{
//
//		System.setProperty("webdriver.gecko.driver", "D:\\Mrechantuat_mavenproject\\MerchantUatApp\\Drivers\\geckodriver.exe");
//		 driver=new FirefoxDriver();
//		  driver.manage().window().maximize();
//		  driver.manage().deleteAllCookies();
//		  return driver;
//  }

	public void launchUrl()
	{
		//driver.get("http://merchantuat.creditfair.in/admin/login");
		driver.get("https://merchantuat.creditfair.in/admin/login");
	}

	public void closebrowser() throws Exception {
		Thread.sleep(2000);
		driver.close();
	}

}



