package CommonMethod;

import org.openqa.selenium.WebDriver;



public class Chromebrowser {
WebDriver driver;

	public WebDriver launchBrowser()
	{


		System.setProperty("webdriver.chrome.driver", "C:\\Mrechantuat_mavenproject\\MerchantUatApp\\Drivers\\chromedriver.exe");
		//E:\D Drive\Mrechantuat_mavenproject\MerchantUatApp\Drivers\chromedriver.exeE:\D Drive\Mrechantuat_mavenproject\MerchantUatApp\Drivers\chromedriver.exe
		  driver.manage().window().maximize();
		  driver.manage().deleteAllCookies();
		  return driver;

    }

	public void launchAplication()
	{
		driver.get("http://merchantuat.creditfair.in/admin/login");
	}
	
	public void dashbordlaunch()
	{
		driver.get("https://merchantuat.creditfair.in/admin/dashboard");
	}

	public void closebrowser() throws Exception {
		Thread.sleep(2000);
		driver.close();
	}

}


