package PageObject;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class DashboardXpath {
	WebDriver driver;

	public  DashboardXpath(WebDriver Driver) {
		// TODO Auto-generated constructor stub
	

		driver=Driver;
		PageFactory.initElements(Driver,this);
	}
	@FindBy (xpath = "//input[@name=\"username\"]")
	 WebElement Username;

	@FindBy (xpath = "//input[@name=\"password\"]")
	 WebElement password;
    
	@FindBy (xpath = "//button[@id=\"m_login_signin_submit1\"]")
	WebElement signUp;
	
	@FindBy (xpath = "(//span[@class=\"m-menu__link-text\"])[1]")
	 WebElement dashBclick;
	
	@FindBy (xpath = "//input[@placeholder=\"From Date\"]")
	 WebElement Fromdate;
	
	@FindBy (xpath = "//input[@placeholder=\"To Date\"]")
	 WebElement Todate;
	
	@FindBy (xpath = "//div[@class=\"row\"]/div[3]")
	 WebElement merchantClick;
	
	@FindBy (xpath = "(//input[@type=\"radio\"])[1]")
	 WebElement Actiondate ;
	
	@FindBy (xpath = "(//input[@type=\"radio\"])[2]")
	 WebElement Originationdate ;
	
	@FindBy (xpath = "//input[@type=\"submit\"]")
	 WebElement Searchbtn;
	

	public void enterUsername(String useradd)
	{
		Username.sendKeys(useradd);
	}

	public void enterpassword(String passadd)
	{
		password.sendKeys(passadd);
	}
	public void ClickOnSignupButton()
	{
		signUp.click();
	}
	public void dashbord()
	{
		dashBclick.click();;
	}
	public void clearall()
	{
		Fromdate.clear();
	}
	public void fromdate(String Fdate)
	{
		Fromdate.sendKeys(Fdate);
		
	}
	public void enter()
	{
		Fromdate.sendKeys(Keys.ENTER);
	}
	public void Tclearall()
	{
		Todate.clear();
	}
	
	public void todate(String Tdate)
	{
		Todate.sendKeys(Tdate);
		
	}
	public void enter2()
	{
		Todate.sendKeys(Keys.ENTER);
	}
	
//	public void merchnat()
//	{
//		merchantClick.click();
//	}
//	
	public void Actionbutton()
	{
		Actiondate.click();;
	}
	
	public void originalbutton()
	{
	 Originationdate.click();	
	}
	
	public void Searchbtn()
	{
		Searchbtn.click();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
}


