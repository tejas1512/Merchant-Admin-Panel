package PageObject;

import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class Co_applicant_Xpath {
	Actions act;
	Select sel;
	WebDriver ldriver;

 public Co_applicant_Xpath(WebDriver rDriver) 
  {

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
	}
	


@FindBy (xpath = "//a[@href=\"#nav-co-applicant-details\"]")
WebElement co_applicant;

@FindBy (xpath = "//input[@name=\"co_applicant_name\"]")
WebElement co_applicant_name;

@FindBy (xpath = "//input[@name=\"co_applicant_father_name\"]")
WebElement co_applicant_father_name;

@FindBy (xpath = "//input[@name=\"co_applicant_relationship\"]")
WebElement co_applicant_relationship;

@FindBy (xpath = "//input[@id=\"co_dob_datetimepicker\"]")
WebElement co_applicant_dob;

@FindBy (xpath = "//select[@name=\"co_applicant_gender\"]")
WebElement co_applicant_gender;

@FindBy (xpath = "//input[@name=\"co_applicant_pan_card\"]")
WebElement co_applicant_pan;

@FindBy (xpath = "//input[@name=\"co_applicant_email\"]")
WebElement co_applicant_email;

@FindBy (xpath = "//input[@name=\"co_applicant_mobile_number\"]")
WebElement co_applicant_mobile_num;

@FindBy (xpath = "//select[@name=\"co_applicant_address_status\"]")
WebElement co_applicant_address_status ;

@FindBy (xpath = "//input[@name=\"co_applicant_address_line_1\"]")
WebElement co_applicant_address;

@FindBy (xpath = "//input[@name=\"co_applicant_address_city\"]")
WebElement co_applicant_city;

@FindBy (xpath = "//input[@name=\"co_applicant_address_landmark\"]")
WebElement co_applicant_landmark;

@FindBy (xpath = "//input[@id=\"co_applicant_address_pincode\"]")
WebElement co_applicant_pincode;

@FindBy (xpath = "//select[@id=\"co_applicant_address_state\"]")
WebElement co_applicant_state;

@FindBy (xpath = "//select[@name=\"co_applicant_employee_status\"]")
WebElement co_applicant_emp_status;

@FindBy (xpath = "//input[@name=\"co_applicant_monthly_income\"]")
WebElement co_applicant_income;

@FindBy (xpath = "//input[@name=\"co_applicant_company_name_search\"]")
WebElement co_applicant_com_name;

@FindBy (xpath = "//input[@name=\"co_applicant_designation\"]")
WebElement co_applicant_designation;

@FindBy (xpath = "//input[@name=\"co_applicant_experience\"]")
WebElement co_applicant_experience;

@FindBy (xpath = "//select[@name=\"co_applicant_required\"]")
WebElement co_applicant_required;

@FindBy (xpath = "(//button[@type=\"submit\"])[1]")
WebElement submit_button;



public void Co_applicant_details() throws Exception 

{   
	co_applicant.click();
	Thread.sleep(1000);
	co_applicant_name.sendKeys("credit");
	co_applicant_father_name.sendKeys("Test");
	co_applicant_relationship.sendKeys("Test");
	co_applicant_dob.sendKeys("1996-07-18");
	co_applicant_dob.sendKeys(Keys.ENTER);
	sel= new Select(co_applicant_gender);
	sel.selectByIndex(1);
	co_applicant_pan.sendKeys("THYUI6756H");
	co_applicant_email.sendKeys("credit@gmail.com");
	co_applicant_mobile_num.sendKeys("9798675677");
	sel= new Select(co_applicant_address_status);
	sel.selectByIndex(3);
	co_applicant_address.sendKeys("sion");
	co_applicant_city.sendKeys("mumbai");
	co_applicant_landmark.sendKeys("antophill");
	co_applicant_pincode.sendKeys("400012");
	sel=new Select(co_applicant_state);
	sel.selectByIndex(21);
	sel=new Select(co_applicant_emp_status);
	sel.selectByIndex(2);
	co_applicant_income.sendKeys("50000");
	co_applicant_com_name.sendKeys("credit");
	co_applicant_designation.sendKeys("QA");
	co_applicant_experience.sendKeys("1");
	sel=new Select(co_applicant_required);
	sel.selectByIndex(1);
	Thread.sleep(1000);
	submit_button.sendKeys(Keys.ENTER);
	submit_button.click();
	
	
	
	
	
	
}







}
