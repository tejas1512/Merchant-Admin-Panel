package PageObject;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class Emi_CalculatorXpath 
{
	Actions act;
	WebDriver ldriver;

	public  Emi_CalculatorXpath(WebDriver rDriver) {

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
	}
	
	@FindBy (xpath = "//input[@name=\"username\"]")
	 WebElement Username;

	@FindBy (xpath = "//input[@name=\"password\"]")
	 WebElement password;

	@FindBy (xpath = "//button[@id=\"m_login_signin_submit1\"]")
	WebElement signUp;
	
	@FindBy (xpath = "(//span[@class=\"m-menu__link-text\"])[3]")
	 WebElement consection;
	
	@FindBy (xpath = "//input[@id=\"loan_amount\"]")
	 WebElement loan_amount;
	
	@FindBy (xpath = "//input[@id=\"net_loan_amount\"]")
	 WebElement Net_loan_amount;
	
	@FindBy (xpath = "//input[@id=\"emi_amount\"]")
	 WebElement emi_amount;
	
	@FindBy (xpath = "//button[text()=\"Calculate EMI\"]")
	 WebElement calculate;
	
	@FindBy (xpath = "//img[@src=\"https://merchantuat.creditfair.in/assets/app/media/img/users/user-placeholder.png\"]")
	WebElement clickicon;

	@FindBy (xpath = "//a[@href=\"https://merchantuat.creditfair.in/admin/logout\"]")
	WebElement clickLogoutBtn;
	
	public void enterUsername(String useradd)
	{
		Username.sendKeys(useradd);
	}

	public void enterpassword(String passadd)
	{
		password.sendKeys(passadd);
	}
	public void ClickOnSignupButton()
	{
		signUp.click();
	}
	
	public void conSection()
	{
		consection.click();
	}
	
	public void emi_Calculator() throws Exception {
		act= new Actions(ldriver);
		WebElement Emi_cal=ldriver.findElement(By.xpath("//a[@href=\"https://merchantuat.creditfair.in/admin/emi-calculation\"]"));
		act.moveToElement(Emi_cal).click().build().perform();
		Thread.sleep(1000);
		loan_amount.sendKeys("50000");
		Net_loan_amount.sendKeys("45000");
		emi_amount.sendKeys("15000");
		Thread.sleep(1000);
		calculate.click();
	}
	
	public void logout_page() throws Exception {
		Thread.sleep(2000);
		clickicon.click();
		Thread.sleep(1000);
		clickLogoutBtn.click();
	}


}
