package PageObject;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class LoginpageObject {

	WebDriver ldriver;

	public LoginpageObject(WebDriver rDriver) {

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
	}

	@FindBy (xpath = "//input[@name=\"username\"]")
	 WebElement Username;

	@FindBy (xpath = "//input[@name=\"password\"]")
	 WebElement password;

	@FindBy (xpath = "//button[@id=\"m_login_signin_submit1\"]")
	WebElement signUp;

	@FindBy (xpath = "//img[@src=\"https://merchantuat.creditfair.in/assets/app/media/img/users/user-placeholder.png\"]")
	WebElement clickicon;

	@FindBy (xpath = "//a[@href=\"https://merchantuat.creditfair.in/admin/logout\"]")
	WebElement clickLogoutBtn;

	public void enterUsername(String useradd)
	{
		Username.sendKeys(useradd);
	}

	public void enterpassword(String passadd)
	{
		password.sendKeys(passadd);
	}
	public void ClickOnSignupButton()
	{
		signUp.click();
	}
	public void clickLogoutIcon()
	{
		clickicon.click();
	}

	public void clickLogoutBtn()
	{
		clickLogoutBtn.click();
	}


}
