package PageObject;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;
import org.openqa.selenium.support.ui.WebDriverWait;

public class FilterXpath {
		Actions act;
		Select sel;
		WebDriver ldriver;
		JavascriptExecutor js;
	

	  public FilterXpath(WebDriver rDriver) 
	  {
            ldriver=rDriver;
			PageFactory.initElements(rDriver,this);
		}
	  
	 @FindBy (xpath = "//input[@name=\"username\"]")
		 WebElement Username;

	@FindBy (xpath = "//input[@name=\"password\"]")
		 WebElement password;

	@FindBy (xpath = "//button[@id=\"m_login_signin_submit1\"]")
		WebElement signUp;
	
	@FindBy (xpath = "(//span[@class=\"m-menu__link-text\"])[3]")
	 WebElement consection;
	
	@FindBy (xpath = "(//span[text()=\"Select Status\"])[1]")
	 WebElement select_status;
	
	@FindBy (xpath = "(//div[@class=\"bs-searchbox\"])[3]")
	 WebElement select_search;
	
	@FindBy (xpath = "//select[@name=\"_application_status\"]")
	 WebElement select_search_1;
	
	@FindBy (xpath = "//button[@type=\"submit\"]")
	 WebElement Search_btn;
	
	@FindBy (xpath = "(//button[@class=\"btn\"])[1]")
	 WebElement View_status;
	
	@FindBy (xpath = "(//span[@id=\"send_mail\"])[1]")
	 WebElement kyc_applicant;
	
	@FindBy (xpath = "//button[@id=\"sendMailBtn\"]")
	 WebElement send_kyc;
	
	@FindBy (xpath = "(//span[@id=\"send_mail\"])[2]")
	 WebElement kyc_co_applicant;
	
	@FindBy (xpath = "//button[@id=\"sendMailBtn\"]")
	 WebElement send_kyc_coapp;
	
	@FindBy (xpath = "(//span[@id=\"send_mail\"])[3]")
	 WebElement Nach_click;
	
	@FindBy (xpath = "//button[@id=\"sendMailBtn\"]")
	 WebElement send_nach;
	
	@FindBy (xpath = "(//span[@id=\"send_mail\"])[4]")
	 WebElement E_sign;
	
	@FindBy (xpath = "//button[@id=\"sendMailBtn\"]")
	 WebElement E_sign_btn;
	
	
	
	
	public void enterUsername(String useradd)
	{
		Username.sendKeys(useradd);
	}

	public void enterpassword(String passadd)
	{
		password.sendKeys(passadd);
	}
	public void ClickOnSignupButton()
	{
		signUp.click();
	}
	
	public void conSection()
	{
		consection.click();
	}
	
	
	public void Filteradd() throws Exception 
	{
		
		select_status.click();
		
		sel= new Select(select_search_1);
		sel.selectByIndex(8);
		Search_btn.click();
		//Thread.sleep(1000);
		js=	(JavascriptExecutor) ldriver;
		js.executeScript("window.scrollBy(0,300)");
		View_status.click();
		Thread.sleep(2000);
		kyc_applicant.click();
		//Thread.sleep(1000);
		send_kyc.click();
		Thread.sleep(20000);
        Alert a1=ldriver.switchTo().alert();
		a1.accept();
		//System.out.println(a1.getText());
	
		
		
	}
	
	public void kyc_Coapplicant() throws Exception {
		Thread.sleep(2000);
        kyc_co_applicant.click();
		//Thread.sleep(1000);
		send_kyc_coapp.click();
		Thread.sleep(20000);
        Alert a1=ldriver.switchTo().alert();
		a1.accept();
		//System.out.println(a1.getText());
		
		
	}
	
	public void Nach_send() throws Exception {
		Thread.sleep(2000);
       Nach_click.click();
		//Thread.sleep(1000);
		send_nach.click();
		Thread.sleep(20000);
        Alert a1=ldriver.switchTo().alert();
		a1.accept();
		//System.out.println(a1.getText());
		
	}
	
	public void E_sign_send() throws Exception {
		Thread.sleep(2000);
	        E_sign.click();
			//Thread.sleep(1000);
			E_sign_btn.click();
			Thread.sleep(20000);
	        Alert a1=ldriver.switchTo().alert();
			a1.accept();
			//System.out.println(a1.getText());
			
		}
	

}

