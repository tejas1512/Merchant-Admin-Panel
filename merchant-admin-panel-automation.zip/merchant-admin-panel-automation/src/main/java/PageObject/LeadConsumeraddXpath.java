package PageObject;

import org.openqa.selenium.Alert;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class LeadConsumeraddXpath {
	
	
	
	Actions act;
	Select sel;
	JavascriptExecutor js;
	
	WebDriver ldriver;

    public LeadConsumeraddXpath(WebDriver rDriver) {

		ldriver=rDriver;
		PageFactory.initElements(rDriver,this);
	}
    
    
    @FindBy (xpath = "//input[@name=\"username\"]")
	 WebElement Username;

	@FindBy (xpath = "//input[@name=\"password\"]")
	 WebElement password;

	@FindBy (xpath = "//button[@id=\"m_login_signin_submit1\"]")
	WebElement signUp;
	
	@FindBy (xpath = "(//span[@class=\"m-menu__link-text\"])[3]")
	 WebElement consection;
	
	@FindBy (xpath = "//a[@href=\"https://merchantuat.creditfair.in/admin/consumer-applications\"]")
	 WebElement consection2;
	
	@FindBy (xpath = "//a[@href=\"https://merchantuat.creditfair.in/admin/consumer-applications/lead-add\"]")
	 WebElement leadconsumer;

	@FindBy (xpath = "//h4[@href=\"#collapse1\"]")
	 WebElement collapse1;
	
	@FindBy (xpath = "(//select[@id=\"exampleSelect1\"])[1]")
	 WebElement prelanguage;
	
	
	
	@FindBy (xpath = "//input[@name=\"name\"]")
	 WebElement FulltName;
	
	@FindBy (xpath = "//input[@name=\"father_name\"]")
	 WebElement Fathername;
	
	@FindBy (xpath = "//input[@name=\"email\"][1]")
	 WebElement emailid;
	
	@FindBy (xpath = "//input[@name=\"mobile_number\"][1]")
	 WebElement mobile1;
	
	@FindBy (xpath = "//input[@name=\"pan_card\"]")
	 WebElement panno;

	@FindBy (xpath = "(//select[@id=\"exampleSelect1\"])[2]")
	 WebElement Gender;
	
	@FindBy (xpath = "//input[@id=\"date_of_birth_datepicker\"]")
	 WebElement dob;
	
	@FindBy (xpath = "//input[@name=\"monthly_income\"]")
	 WebElement monthlyincome;
	
	@FindBy (xpath = "//input[@name=\"loan_amount\"]")
	 WebElement loanamount;
	
//	@FindBy (xpath = "(//button[@type=\"button\"])[4]")
//	 WebElement select_merchant;
	
	@FindBy (xpath = "//select[@name=\"offer_id\"]")
	 WebElement select_tenure;
	
	@FindBy (xpath = "//input[@name=\"approved_amount\"]")
	WebElement approvedamount;
	
	@FindBy (xpath = "(//input[@placeholder=\"Product Name\"])[1]")
	 WebElement productname;
	
	@FindBy (xpath = "//select[@name=\"marital_status\"]")
	 WebElement maritalstatus;
	
	@FindBy (xpath = "//input[@name=\"video_kyc\"]")
	 WebElement videokyclink;
	
	@FindBy (xpath = "//h4[@href=\"#collapse4\"]")
	 WebElement collapse2;
	
	@FindBy (xpath = "//select[@name=\"employee_status\"]")
	 WebElement empstatus;
	
	@FindBy (xpath = "//input[@name=\"company_name_search\"]")
	 WebElement company_name;
	
	@FindBy (xpath = "//input[@name=\"company_number\"]")
	 WebElement company_number;
	
	@FindBy (xpath = "//select[@name=\"industry\"]")
	 WebElement industry;
	
	@FindBy (xpath = "//select[@name=\"profession\"]")
	 WebElement companytype;
	
	@FindBy (xpath = "//input[@name=\"experience\"]")
	 WebElement experience;
	
	@FindBy (xpath = "(//input[@name=\"work_address_pincode\"])[1]")
	 WebElement work_address_pincode;
	
	@FindBy (xpath = "//input[@name=\"designation\"]")
	 WebElement designation;
	
	@FindBy (xpath = "//input[@name=\"department\"]")
	 WebElement department;
	
	@FindBy (xpath = "//input[@name=\"contact\"]")
	 WebElement contact;
	
	@FindBy (xpath = "//input[@name=\"linkedin\"]")
	 WebElement linkedin;
	
	@FindBy (xpath = "//h4[@href=\"#collapse3\"]")
	 WebElement collapse3;
	
	@FindBy (xpath = "//input[@name=\"permanent_address_line_1\"]")
	 WebElement permanentaddressline;
	
	@FindBy (xpath = "//input[@name=\"permanent_address_city\"]")
	 WebElement permanentaddresscity;
	
	@FindBy (xpath = "//input[@name=\"permanent_address_landmark\"]")
	 WebElement permanentaddresslandmark;
	
	@FindBy (xpath = "//input[@name=\"permanent_address_pincode\"]")
	 WebElement permanentaddresspincode;
	
	@FindBy (xpath = "//select[@name=\"permanent_address_state\"]")
	 WebElement permanent_address_state;
	
	
	@FindBy (xpath = "(//select[@name=\"permanent_address_status\"])")
	 WebElement permanent_address_status;
	
	@FindBy (xpath = "//input[@id=\"checkboxAddress\"]")
	 WebElement ischecked_1;
	
	@FindBy (xpath = "(//button[@type=\"submit\"])[1]")
	 WebElement submit_1;
	
	public void enterUsername(String useradd)
	{
		Username.sendKeys(useradd);
	}

	public void enterpassword(String passadd)
	{
		password.sendKeys(passadd);
	}
	public void ClickOnSignupButton()
	{
		signUp.click();
	}
	
	public void conSection()
	{
		consection.click();
	}
	
	public void Leadaddconsumer()
	{
		leadconsumer.click();
	}
	
	public void Collapse()
	{
		collapse1.click();
	}
	
	public void Lead_Application_details() throws Exception
	{
		sel=new Select(prelanguage);
		sel.selectByIndex(2);
		js=	(JavascriptExecutor) ldriver;
		js.executeScript("window.scrollBy(0,100)");
		FulltName.sendKeys("CreditTest");
		Fathername.sendKeys("Test");
		emailid.sendKeys("naveen.barai@creditfair.in");
		mobile1.sendKeys("9090999999");
		panno.sendKeys("YUTUU6787R");
		sel=new Select(Gender);
		sel.selectByIndex(1);
		//dob.click();
		dob.sendKeys("1996-03-07");
		dob.sendKeys(Keys.ENTER);
		js=	(JavascriptExecutor) ldriver;
		js.executeScript("window.scrollBy(0,100)");
		monthlyincome.sendKeys("50000");
		loanamount.sendKeys("60000");
		sel=new Select(select_tenure);
		sel.selectByIndex(1);
		approvedamount.sendKeys("60000");
		productname.sendKeys("Test");
		js=	(JavascriptExecutor) ldriver;
		js.executeScript("window.scrollBy(0,100)");
		sel= new Select(maritalstatus);
		sel.selectByIndex(1);
		videokyclink.sendKeys("www.google.com");
		Thread.sleep(1000);
	}
	
	public void Lead_Employment_details()
	{
		collapse2.click();
		sel= new Select(empstatus);
		sel.selectByIndex(2);
		company_name.sendKeys("creditfair");
		company_number.sendKeys("123456");
		sel=new Select(industry);
		sel.selectByIndex(1);
		sel=new Select(companytype);
		sel.selectByIndex(1);
		experience.sendKeys("1");
		work_address_pincode.sendKeys("400012");
		designation.sendKeys("QA");
		department.sendKeys("IT");
		contact.sendKeys("7867688787");
		linkedin.sendKeys("www.linkedin/naveen.in");
		
	}
	
	public void Lead_Applicatant_address() 
	{
		collapse3.click();
		permanentaddressline.sendKeys("Sion");
		permanentaddresscity.sendKeys("mumbai");
		permanentaddresslandmark.sendKeys("gtb nagar");
		permanentaddresspincode.sendKeys("400037");
		permanent_address_state.click();
		permanent_address_state.sendKeys(Keys.ENTER);
		sel= new Select(permanent_address_status);
		sel.selectByIndex(3);
		js=	(JavascriptExecutor) ldriver;
		js.executeScript("window.scrollBy(0,100)");
		ischecked_1.click();
		submit_1.click();;
		Alert a1=ldriver.switchTo().alert();
		a1.accept();
		
		
	}
	
	
	
	
	


}

	


