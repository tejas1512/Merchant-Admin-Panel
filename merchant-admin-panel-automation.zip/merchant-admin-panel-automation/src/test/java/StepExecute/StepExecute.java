package StepExecute;



import org.junit.runner.RunWith;


import io.cucumber.junit.Cucumber;
import io.cucumber.junit.CucumberOptions;

@RunWith(Cucumber.class)
@CucumberOptions(

		features = "C:\\Users\\Lenovo\\git\\merchant-admin-panel-automation\\src\\test\\java\\AppFeatures",
		glue = "StepDefination",
		dryRun = false,
		//tags= "@Sanity",
	    monochrome = true,
		plugin = {"pretty","html:target/cucumber_report/report.html"}


		)

public class StepExecute  {

	
	 
	
}

