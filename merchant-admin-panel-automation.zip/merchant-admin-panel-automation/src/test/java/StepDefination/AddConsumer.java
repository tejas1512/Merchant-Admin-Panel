package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;


import PageObject.Co_applicant_Xpath;
import PageObject.ConsumerAddxpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class AddConsumer {
	
public WebDriver driver;
public ConsumerAddxpath obj;
public Co_applicant_Xpath co_obj;

Actions act;


@Given("I want User open a WebBrowsers")

public void i_want_user_open_a_web_browsers() {
	WebDriverManager.chromedriver().setup();
	ChromeOptions options=new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
//	options.addArguments("headless");
	driver=new ChromeDriver(options);
	driver.manage().window().maximize();
	obj=new ConsumerAddxpath(driver);
	co_obj=new Co_applicant_Xpath(driver);
	
	
    
}

@When("I want User Enter a Urls {string}")
public void i_want_user_enter_a_urls(String url) throws Exception {
	Thread.sleep(1000);
	driver.get(url);
	
}


@Then("I want User Enter a valid USERNAME {string} and vaild PASSWORD {string}")
public void i_want_user_enter_a_valid_username_and_vaild_password(String username, String password) {
	
	obj.enterUsername(username);
	obj.enterpassword(password);
	obj.ClickOnSignupButton();
    
}

@Then("User click to Add consumer application and Applicat details")
public void user_click_to_add_consumer_application_and_applicat_details() throws Exception{
	Thread.sleep(1000);
	obj.conSection();
	act=new Actions(driver);
	WebElement consection2=driver.findElement(By.xpath("//a[@href=\"https://merchantuat.creditfair.in/admin/consumer-applications\"]"));
	act.moveToElement(consection2).click().build().perform();
	obj.addConsumer();
	obj.Collapse();
	Thread.sleep(1000);
	obj.Application_details();
   
}

@Then("User Add Employement deatils")
public void user_add_employement_deatils() {
	obj.Employment_details();
   
}

@Then("User Add Applicant Address")
public void user_add_applicant_address() {
	obj.Applicatant_address();
   
}

@Then("User Add Co_applicant_details")
public void user_add_co_applicant_details() throws Exception {
	Thread.sleep(1000);
	driver.get("https://merchantuat.creditfair.in/admin/consumer-applications/add#nav-co-applicant-details");
	co_obj.Co_applicant_details();
   
}



@Then("User Click submit button")
public void user_click_submit_button() {
	driver.close();
	
   
}


}
