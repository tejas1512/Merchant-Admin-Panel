package StepDefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import PageObject.Emi_CalculatorXpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class EMI_Calculatorstep 

{
	WebDriver driver;
	public Emi_CalculatorXpath emi_obj;
	

@Given("User want open a Browser")
public void user_want_open_a_browser() {
	
	WebDriverManager.chromedriver().setup();
	ChromeOptions options=new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	driver=new ChromeDriver(options);
	driver.manage().window().maximize();
	emi_obj=new Emi_CalculatorXpath(driver);
    
}

@Given("User Enter a Urls {string}")
public void user_enter_a_urls(String url) throws Exception {

	Thread.sleep(1000);
	driver.get(url);
	
}

@Then("User Enter a valid USERNAME {string} and vaild PASSWORD {string}")
public void user_enter_a_valid_username_and_vaild_password(String username, String password) {
	emi_obj.enterUsername(username);
	emi_obj.enterpassword(password);
	emi_obj.ClickOnSignupButton();
	
}

@When("User calculate the EMI")
public void user_calculate_the_emi() throws Exception {
	emi_obj.conSection();
	Thread.sleep(2000);
	emi_obj.emi_Calculator();
   
}

@When("User click the logout button")
public void user_click_the_logout_button() throws Exception {
	
	emi_obj.logout_page();
	Thread.sleep(1000);
	driver.close();
    
}


}
