package StepDefination;



import java.io.IOException;


import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import Assertion.MatchUrl;
import PageObject.LoginpageObject;
import io.cucumber.java.en.*;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Steplogin {


		public WebDriver driver;
		public LoginpageObject obj;
		MatchUrl murl;
		JavascriptExecutor js;
		


	@Given("I want User open a Browser")
	public void i_want_user_open_a_browser() {


		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		obj=new LoginpageObject(driver);


	}

	@Then("I want User Enter a url {string}")
	public void i_want_user_enter_a_url(String  url) throws Exception {
		Thread.sleep(2000);
	    driver.get(url);
	}

	@When("I want User Enter a valid Username {string} and vaild password {string}")
	public void i_want_user_enter_a_valid_username_and_vaild_password(String UserN, String pwd) throws Exception {
	 Thread.sleep(1000);
	 
	  obj.enterUsername(UserN);
	  obj.enterpassword(pwd);
	  js=(JavascriptExecutor)driver;
	  js.executeScript("window.scrollBy(0,100)");
	  Thread.sleep(1000);
	}

	@Then("User click as Signup Btn")
	public void user_click_as_signup_btn() throws IOException {
	  obj.ClickOnSignupButton();
	}

	@When("User Redirect the Home Page {string}")
	public void user_redirect_the_home_page(String MatchHomepageurl) throws Exception {
	  Thread.sleep(2000);
	  murl=new MatchUrl();
	  murl.verifyPageURL(MatchHomepageurl, driver.getCurrentUrl());
	  System.out.println(driver.getCurrentUrl());
	}

	@When("User click as Logout Sucessefully")
	public void user_click_as_logout_sucessefully() throws Exception {
		Thread.sleep(1000);
		obj.clickLogoutIcon();
		obj.clickLogoutBtn();
		Thread.sleep(1000);

		driver.close();
		

	}


}

