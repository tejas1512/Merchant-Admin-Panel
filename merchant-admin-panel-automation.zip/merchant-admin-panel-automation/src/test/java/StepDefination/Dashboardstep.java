package StepDefination;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;

import PageObject.DashboardXpath;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Dashboardstep  {
 
	WebDriver driver;
	public DashboardXpath dashxpath;
	
	@Given("I want User open a WebBrowser")
	public void i_want_user_open_a_web_browser() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		dashxpath=new DashboardXpath(driver);

	   
	}
	@Then("I want User Enter a urls {string}")
	public void i_want_user_enter_a_urls(String urLs) throws Exception 
	
	{
		Thread.sleep(2000);
	   driver.get(urLs);
	}

	@When("I want User Enter a valid Usernames {string} and vaild passwords {string}")
 public void i_want_user_enter_a_valid_usernames_and_vaild_passwords(String useradd, String Password) 
	{
			    dashxpath.enterUsername(useradd);
			    dashxpath.enterpassword(Password);
			    dashxpath.ClickOnSignupButton();
	}
	@Then("I want User Enter a URL {string}")
	public void i_want_user_enter_a_url(String URL) throws Exception {
		Thread.sleep(2000);
	   driver.get(URL);
	    
	}

	@When("User enter From date {string} and to date {string}")
	public void user_enter_from_date_and_to_date(String Date1, String Date2) throws Exception {
		Thread.sleep(2000);
	    dashxpath.dashbord();
	    Thread.sleep(1000);
	     dashxpath.clearall();
	    dashxpath.fromdate(Date1);
	    dashxpath.enter();
	    dashxpath.Tclearall();
	    dashxpath.todate(Date2);
	    dashxpath.enter2();
	   
	}

	@When("User click on Action date and origination date")
	public void user_click_on_action_date_and_origination_date() throws Exception {
		Thread.sleep(2000);
		
	    dashxpath.Actionbutton();
	    Thread.sleep(2000);
	    dashxpath.originalbutton();
	   
	}

	@When("User click on Search button")
	public void user_click_on_search_button() throws Exception {
	    dashxpath.Searchbtn();
	    Thread.sleep(2000);
	    driver.close();
	   
	}

}
