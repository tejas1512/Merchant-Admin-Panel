package StepDefination;

import java.time.Duration;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import PageObject.Co_applicant_Xpath;
import PageObject.FilterXpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class Filter_Status {
  
	public WebDriver driver;
	public FilterXpath fil_obj;
	public Co_applicant_Xpath co_obj;
	Actions act;
	
	

@Given("I want User open a WEDBrowsers")
public void i_want_user_open_a_wed_browsers() {
	WebDriverManager.chromedriver().setup();
	ChromeOptions options=new ChromeOptions();
	options.addArguments("--remote-allow-origins=*");
	driver=new ChromeDriver(options);
	driver.manage().window().maximize();
	fil_obj=new FilterXpath(driver);
	co_obj=new Co_applicant_Xpath(driver);
}

@When("I want User Enter a UrLs {string}")
public void i_want_user_enter_a_ur_ls(String url) throws Exception {
	Thread.sleep(2000);
	driver.get(url);
   
}

@Then("I want User Enter a valid USERnAMES {string} and vaild PASSwORDS {string}")
public void i_want_user_enter_a_valid_use_rn_ames_and_vaild_pas_sw_ords(String username, String password) {
	fil_obj.enterUsername(username);
	fil_obj.enterpassword(password);
	fil_obj.ClickOnSignupButton();
}

@Then("User Click section button")
public void user_add_co_applicant_deatils() throws Exception 
{
	Thread.sleep(1000);
	fil_obj.conSection();
	act=new Actions(driver);
	WebElement consection2=driver.findElement(By.xpath("//a[@href=\"https://merchantuat.creditfair.in/admin/consumer-applications\"]"));
	act.moveToElement(consection2).click().build().perform();
	Thread.sleep(1000);
	
}

@SuppressWarnings("deprecation")
@Then("User click on status button")
public void user_click_on_status_button() throws Exception{
	driver.manage().timeouts().implicitlyWait(30,TimeUnit.SECONDS);
	fil_obj.Filteradd();
	Thread.sleep(4000);
	fil_obj.kyc_Coapplicant();
	Thread.sleep(4000);
	fil_obj.Nach_send();
	Thread.sleep(4000);
	fil_obj.E_sign_send();
	driver.close();
    
}

}
