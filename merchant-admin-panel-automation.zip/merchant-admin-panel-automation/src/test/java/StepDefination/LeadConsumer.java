package StepDefination;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.interactions.Actions;

import PageObject.ConsumerAddxpath;
import PageObject.LeadConsumeraddXpath;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.github.bonigarcia.wdm.WebDriverManager;

public class LeadConsumer {
	public WebDriver driver;
	public LeadConsumeraddXpath obj;
	Actions act;

	@Given("I want User open a WEBBORWSER")
	public void i_want_user_open_a_webborwser() {
		WebDriverManager.chromedriver().setup();
		ChromeOptions options=new ChromeOptions();
		options.addArguments("--remote-allow-origins=*");
		driver=new ChromeDriver(options);
		driver.manage().window().maximize();
		obj=new LeadConsumeraddXpath(driver);
	    
	}

	@When("I want User Enter a URLS {string}")
	public void i_want_user_enter_a_urls(String url) throws Exception {
		Thread.sleep(1000);
		driver.get(url);
	  
	}

	@Then("I want User Enter a valid USERNAMES {string} and vaild PASSWORDS {string}")
	public void i_want_user_enter_a_valid_usernames_and_vaild_passwords(String userName, String Password) {
		obj.enterUsername(userName);
		obj.enterpassword(Password);
		obj.ClickOnSignupButton();
	   
	}

	@Then("User click to Add Lead consumer application and Applicat details")
	public void user_click_to_add_lead_consumer_application_and_applicat_details() throws Exception {
		Thread.sleep(1000);
		obj.conSection();
		act=new Actions(driver);
		WebElement consection2=driver.findElement(By.xpath("//a[@href=\"https://merchantuat.creditfair.in/admin/consumer-applications\"]"));
		act.moveToElement(consection2).click().build().perform();
		obj.Leadaddconsumer();
		obj.Collapse();
		Thread.sleep(1000);
		obj.Lead_Application_details();
	   
		
	}

	@Then("User Add Lead Employement deatils")
	public void user_add_lead_employement_deatils() {
	   obj.Lead_Employment_details();
	}

	@Then("User Add Lead Applicant Address")
	public void user_add_lead_applicant_address() {
		obj.Lead_Applicatant_address();
	   
	}

	@Then("User Click On submit button")
	public void user_click_on_submit_button() {
		driver.close();
	    
	}


}
